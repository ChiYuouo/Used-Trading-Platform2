package com.wsk.tool;

import cn.hutool.crypto.digest.MD5;
import net.coobird.thumbnailator.Thumbnails;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by wsk1103 on 2017/5/14.
 */
public class StringUtils {

    private static class LayHolder {
        private static final StringUtils instance = new StringUtils();
    }

    private StringUtils() {
    }

    public static StringUtils getInstance() {
        return LayHolder.instance;
    }

    public String replaceBlank(String str) {
        String dest = "";
        if (str != null) {
            Pattern p = Pattern.compile("\\s*|\t|\r|\n");
            Matcher m = p.matcher(str);
            dest = m.replaceAll("");
        }
        return dest;
    }

    public String getRandomChar() {
        Random random = new Random();
        String s = "qw2ert1yui6opa7s3df9ghj5klz0x4cv8bnmQWERTYUIOPASDFGHJKLZXCVBNM";
        StringBuffer stringBuffer = new StringBuffer();
        char[] chars = s.toCharArray();
        for (int i = 0; i < 10; i++) {
            stringBuffer.append(chars[random.nextInt(s.length())]);
        }
        return stringBuffer.toString();
    }

    public String DateToString(Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String result = simpleDateFormat.format(date);
        return result;
    }

    public boolean isPhone(String phone) {
        if (phone == null) {
            return false;
        }
        Pattern p = Pattern.compile("^1[3-9]\\d{9}$");
        Matcher m = p.matcher(phone);
        return m.matches();
    }

    public String normalizeImagePath(String path) {
        if (isNullOrEmpty(path)) {
            return "/img/home/feature_prodects/cont1.jpg";
        }
        String normalized = path.trim().replace("\\", "/");
        if (normalized.startsWith("http://") || normalized.startsWith("https://")) {
            return normalized;
        }
        if (!normalized.startsWith("/")) {
            normalized = "/" + normalized;
        }
        return normalized;
    }

    public String getMD5(String str) {
//        String result = "";
        return MD5.create().digestHex(str);
//            MessageDigest md5 = MessageDigest.getInstance("MD5");
////            BASE64Encoder base64Encoder = new BASE64Encoder();
////            result = base64Encoder.encode(md5.digest(str.getBytes("UTF-8")));
//            result = new String(md5.digest(str.getBytes()));
//        return result;
    }

    public boolean isNullOrEmpty(Object obj) {
        if (obj == null)
            return true;

        if (obj instanceof CharSequence)
            return ((CharSequence) obj).length() == 0;

        if (obj instanceof Collection)
            return ((Collection) obj).isEmpty();

        if (obj instanceof Map)
            return ((Map) obj).isEmpty();

        if (obj instanceof Object[]) {
            Object[] object = (Object[]) obj;
            if (object.length == 0) {
                return true;
            }
            boolean empty = true;
            for (int i = 0; i < object.length; i++) {
                if (!isNullOrEmpty(object[i])) {
                    empty = false;
                    break;
                }
            }
            return empty;
        }
        return false;
    }

    public ArrayList<String> readTxt() throws IOException {
        ArrayList<String> list = new ArrayList<>();
        File file = new File("txt/all.txt");
        if (!file.exists()) {
            file = new File("D:\\image\\txt\\all.txt");
        }
        if (!file.exists()) {
            return list;
        }
        String encoding = "GBK";
        try (InputStreamReader reader = new InputStreamReader(new FileInputStream(file), encoding);
             BufferedReader bufferedReader = new BufferedReader(reader)) {
            String txt;
            while ((txt = bufferedReader.readLine()) != null) {
                if (!txt.trim().isEmpty()) {
                    list.add(txt.trim());
                }
            }
        }
        return list;
    }

    public String txtReplace(String test) {
        if (test == null) {
            return null;
        }
        try {
            ArrayList<String> list = readTxt();
            for (String aList : list) {
                test = test.replace(aList, "**");
            }
        } catch (IOException e) {
            e.printStackTrace();
            return test;
        }
        return test;
    }

    public boolean thumbnails(String path, String save) {
        try {
            File saveFile = new File(save);
            if (saveFile.getParentFile() != null && !saveFile.getParentFile().exists()) {
                saveFile.getParentFile().mkdirs();
            }
            Thumbnails.of(path).size(215, 229).toFile(saveFile);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        System.err.println(getInstance().getMD5("123456"));
    }
}
